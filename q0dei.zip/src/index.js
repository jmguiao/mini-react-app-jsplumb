import React from "react";
import ReactDOM from "react-dom";
import MyJsPlumb from "./App";

const rootElement = document.getElementById("root");
ReactDOM.render(<MyJsPlumb />, rootElement);
